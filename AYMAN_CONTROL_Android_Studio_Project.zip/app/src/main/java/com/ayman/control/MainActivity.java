package com.ayman.control;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.Toast;
import android.graphics.drawable.GradientDrawable;

public class MainActivity extends Activity {
    private int blue = Color.rgb(40, 125, 255);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22, 24, 22, 22);
        root.setBackgroundColor(Color.rgb(7, 18, 43));

        ImageView banner = new ImageView(this);
        banner.setImageResource(R.drawable.ayman_background);
        banner.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(banner, new LinearLayout.LayoutParams(-1, 210));

        TextView title = new TextView(this);
        title.setText("AYMAN CONTROL");
        title.setTextColor(Color.WHITE);
        title.setTextSize(25);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 18, 0, 8);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("لوحة تحكم عائمة • Android • Anime Blue");
        subtitle.setTextColor(Color.rgb(155, 205, 255));
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 0, 0, 18);
        root.addView(subtitle);

        Button permission = makeButton("1. السماح بالظهور فوق التطبيقات");
        permission.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else {
                Toast.makeText(this, "الإذن مفعّل بالفعل", Toast.LENGTH_SHORT).show();
            }
        });
        root.addView(permission);

        Button start = makeButton("2. تشغيل الأيقونة العائمة");
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "فعّل إذن الظهور فوق التطبيقات أولًا", Toast.LENGTH_LONG).show();
                return;
            }
            startService(new Intent(this, FloatingService.class));
            Toast.makeText(this, "تم تشغيل لوحة AYMAN العائمة", Toast.LENGTH_SHORT).show();
        });
        root.addView(start);

        Button roblox = makeButton("فتح Roblox");
        roblox.setOnClickListener(v -> {
            Intent launch = getPackageManager().getLaunchIntentForPackage("com.roblox.client");
            if (launch != null) startActivity(launch);
            else Toast.makeText(this, "لم يتم العثور على Roblox على الجهاز", Toast.LENGTH_LONG).show();
        });
        root.addView(roblox);

        TextView note = new TextView(this);
        note.setText("مهم: هذه لوحة عائمة واختصارات واجهة فقط. لا تغيّر السرعة أو المال أو مواقع الشخصية داخل Roblox تلقائيًا. هذه الوظائف تتطلب دعمًا من لعبتك في Roblox Studio.");
        note.setTextColor(Color.LTGRAY);
        note.setTextSize(13);
        note.setPadding(4, 20, 4, 0);
        root.addView(note);

        setContentView(root);
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(blue);
        bg.setCornerRadius(24);
        b.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 7, 0, 7);
        b.setLayoutParams(lp);
        return b;
    }
}
