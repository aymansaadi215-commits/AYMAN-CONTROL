package com.ayman.control;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class FloatingService extends Service {
    private WindowManager wm;
    private View bubble;
    private View panel;
    private WindowManager.LayoutParams bubbleParams, panelParams;
    private boolean expanded = false;

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createBubble();
    }

    private int overlayType() {
        return android.os.Build.VERSION.SDK_INT >= 26
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private GradientDrawable rounded(int color, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(28);
        d.setStroke(3, strokeColor);
        return d;
    }

    private void createBubble() {
        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ayman_icon);
        icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        icon.setBackground(rounded(Color.rgb(13, 34, 78), Color.rgb(80, 180, 255)));
        icon.setClipToOutline(true);
        bubble = icon;

        bubbleParams = new WindowManager.LayoutParams(
            76, 76, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = 24;
        bubbleParams.y = 220;

        bubble.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean dragged;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX(); downY = e.getRawY();
                        startX = bubbleParams.x; startY = bubbleParams.y;
                        dragged = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                        if (Math.abs(dx) + Math.abs(dy) > 8) dragged = true;
                        bubbleParams.x = startX + (int) dx;
                        bubbleParams.y = startY + (int) dy;
                        wm.updateViewLayout(bubble, bubbleParams);
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!dragged) togglePanel();
                        return true;
                }
                return false;
            }
        });
        wm.addView(bubble, bubbleParams);
    }

    private TextView text(String value, int size) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(Color.WHITE);
        t.setTextSize(size);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private void togglePanel() {
        if (expanded) {
            if (panel != null) { wm.removeView(panel); panel = null; }
            expanded = false;
            return;
        }

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(16, 12, 16, 12);
        box.setBackground(rounded(Color.rgb(7, 22, 54), Color.rgb(65, 155, 255)));

        TextView title = text("AYMAN HUB", 18);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        box.addView(title, new LinearLayout.LayoutParams(-1, 44));

        TextView info = text("لوحة خارجية • اختصارات آمنة", 12);
        info.setTextColor(Color.rgb(150, 210, 255));
        box.addView(info, new LinearLayout.LayoutParams(-1, 32));

        addAction(box, "فتح Roblox", () -> {
            Intent launch = getPackageManager().getLaunchIntentForPackage("com.roblox.client");
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(launch);
            } else Toast.makeText(this, "Roblox غير مثبت", Toast.LENGTH_SHORT).show();
        });
        addAction(box, "مواقع محفوظة: تحتاج تكاملًا داخل لعبتك", () ->
            Toast.makeText(this, "اربط هذا الزر بـ RemoteEvent في لعبتك الخاصة عبر Roblox Studio.", Toast.LENGTH_LONG).show());
        addAction(box, "السرعة والقفز: تحتاج تكاملًا داخل لعبتك", () ->
            Toast.makeText(this, "التطبيق الخارجي لا يستطيع فرض هذه القيم على أي لعبة Roblox.", Toast.LENGTH_LONG).show());
        addAction(box, "إخفاء اللوحة", this::togglePanel);

        panel = box;
        panelParams = new WindowManager.LayoutParams(
            300, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.x = Math.max(12, bubbleParams.x - 10);
        panelParams.y = Math.max(70, bubbleParams.y + 84);
        wm.addView(panel, panelParams);
        expanded = true;
    }

    private void addAction(LinearLayout box, String label, Runnable action) {
        TextView b = text(label, 13);
        b.setPadding(8, 10, 8, 10);
        b.setBackground(rounded(Color.rgb(35, 100, 205), Color.rgb(90, 180, 255)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 5, 0, 5);
        box.addView(b, lp);
        b.setOnClickListener(v -> action.run());
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override public void onDestroy() {
        if (panel != null) { try { wm.removeView(panel); } catch (Exception ignored) {} }
        if (bubble != null) { try { wm.removeView(bubble); } catch (Exception ignored) {} }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
